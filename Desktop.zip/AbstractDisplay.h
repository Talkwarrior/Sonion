#pragma once
#include <qserialport.h>
#include <qserialportinfo.h>
#include <qtoolbar.h>
#include <qdockwidget.h>

class AbstractDisplay abstract :
    public QDockWidget 
{
protected:
    QString type;

    QSerialPort& SerialPort;
    QWidget* contentWidget;
    QToolBar* toolbar;

    virtual ~AbstractDisplay() {};

public:
    AbstractDisplay(QWidget* parent, Qt::WindowFlags flags, QSerialPort& port);
};

