#pragma once
#include "AbstractDisplay.h"
#include <QtWidgets/qtextbrowser.h>
#include <QtWidgets/qpushbutton.h>

class MonitorDisplay :
    public AbstractDisplay
{
protected:
    QTextBrowser* contentWidget;
    QPushButton* clearButton;

    void initLayout();
    void initToolbar();

    ~MonitorDisplay();

private slots:
    void updatecontent();

public:
    MonitorDisplay(QWidget* parent, Qt::WindowFlags flags, QSerialPort& port);
};

