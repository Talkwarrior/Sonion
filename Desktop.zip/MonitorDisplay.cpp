#include "MonitorDisplay.h"
#include "OnionSerialWindow.h"

#include <QtWidgets/qtextbrowser.h>
#include <qerrormessage.h>

MonitorDisplay::MonitorDisplay(	QWidget* parent, Qt::WindowFlags flags, QSerialPort& port)
{
	this->SerialPort = port;
	this->type = "MONITOR";
	connect(this->SerialPort, &QSerialPort::readyRead, this, &MonitorDisplay::updatecontent);
	this->initToolbar();
	this->initLayout();

}

MonitorDisplay::~MonitorDisplay()
{
	if(this->SerialPort.isOpen())
		this->SerialPort.close();
}

void MonitorDisplay::initToolbar()
{

}

void MonitorDisplay::initLayout()
{
	this->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
	this->contentWidget = new QTextBrowser(this);
	

	
	this->setWidget(contentWidget);
}


void MonitorDisplay::updatecontent()
{
	QByteArray p = this->SerialPort.readAll();
	this->contentWidget->append(p);
}