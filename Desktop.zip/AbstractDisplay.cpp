#include "AbstractDisplay.h"

AbstractDisplay::AbstractDisplay(QWidget* parent, Qt::WindowFlags flags, QSerialPort& port)
{
	this->contentWidget = NULL;
	this->toolbar = NULL;
	this->SerialPort = port;
	this->show();
}
